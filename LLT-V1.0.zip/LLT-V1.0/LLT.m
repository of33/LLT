% =========================================================================
% Copyright (c) 2026 Olaf Frommann. All rights reserved.
% This file is part of "Prandtl Lifting-Line Theory (LLT) - Deep Documentation of a Teaching C++ Implementation".
% Distributed under the terms defined in 'LICENSE.txt', which is part of this source code package.
%
% Official source and verification: https://github.com/of33/LLT
% =========================================================================

% =========================================================================
% Lifting-Line Theory (LLT) with Glauert solution (Prandtl lifting line)
% MATLAB/Octave teaching script (code-faithful translation of the C++ version)
%
%  - Coordinate transform:  y = -(span/2) cos(Theta),  Theta in (0, pi)
%  - Fourier ansatz:        Gamma(Theta) = 2 span U_inf * sum_{n=1..N} A_n sin(n Theta)
%  - Glauert result:        alpha_i(Theta) = sum_{n=1..N} n A_n * sin(n Theta)/sin(Theta)
%  - Linear system for A_n: alpha(Theta) = 2span/(pi c(Theta)) * sum A_n sin(nTheta)
%                           + alpha_0(Theta) + sum n A_n sin(nTheta)/sinTheta
%
% Input: HALF-wing planform by 4 corner points (LE/TE at root and tip).
% Symmetry is assumed, so geometry functions use |y|.
%
% Output: distributions over the FULL wing, written as gnuplot-friendly ASCII.
% =========================================================================

function LLT()

    clear; clc;

    % ------------------------------
    % User input (global configuration)
    % ------------------------------

    in.root_le = struct('x', 0.0, 'y', 0.0);  % root LE
    in.root_te = struct('x', 2.0, 'y', 0.0);  % root TE
    in.tip_le  = struct('x', 0.5, 'y', 5.0);  % tip LE (y=b/2)
    in.tip_te  = struct('x', 1.5, 'y', 5.0);  % tip TE (y=b/2)

    in.Uinf = 30.0;                % free-stream speed
    in.alpha = 2.0 * pi/180.0;     % [rad]
    in.alpha_geo_root = 0.0;       % [rad]
    in.alpha_geo_tip  = 0.0;       % [rad]
    in.alpha_0 = 0.0;              % [rad]
    in.a0 = 2.0 * pi;              % dc_l/dalpha [1/rad], thin-airfoil theory

    in.N_full = 40;                % must be even

    % ------------------------------
    % Solve LLT and write output file
    % ------------------------------

    res = run_llt(in);
    write_distributions_full_wing(in, res, 'llt_distribution.dat');

    % Print summary (stdout)
    fprintf('span    = %.10g\n', res.span);
    fprintf('S       = %.10g\n', res.S);
    fprintf('Lambda  = %.10g\n', res.Lambda);
    fprintf('cL      = %.10g\n', res.cL);
    fprintf('cDi     = %.10g\n', res.cDi);
    fprintf('cDi_ell = %.10g\n', res.cDi_ell);
    fprintf('e       = %.10g\n', res.e);
    fprintf('dcL/dalpha (theory) = %.10g [1/rad]\n', res.dcL_dalpha);

    % Lift slope comparison (secant)
    alpha1 = 0.0 * pi/180.0;
    alpha2 = 8.0 * pi/180.0;

    r1 = run_llt(with_alpha(in, alpha1));
    r2 = run_llt(with_alpha(in, alpha2));

    dcL_dalpha_num = (r2.cL - r1.cL) / (alpha2 - alpha1);

    fprintf('\nLift-curve slope comparison:\n');
    fprintf('dcL/dalpha (theory) = %.10g [1/rad]\n', res.dcL_dalpha);
    fprintf('dcL/dalpha (secant, 0..8 deg) = %.10g [1/rad]\n', dcL_dalpha_num);
    fprintf('difference = %.10g [1/rad]\n\n', (dcL_dalpha_num - res.dcL_dalpha));

    % Fourier coefficients
    fprintf('Fourier coefficients A_n:\n');
    for n = 1:length(res.A)
        fprintf('A_%d = %.10g\n', n, res.A(n));
    end

    % =========================================================================
    % Functions (Octave/MATLAB compatible)
    % =========================================================================

    function out = with_alpha(in, alpha_new)
        out = in;
        out.alpha = alpha_new;
    end

    function res = run_llt(in)

        % ---- Input checks / conventions ----
        require(in.N_full >= 4, 'N_full must be >= 4.');
        require(mod(in.N_full, 2) == 0, 'N_full must be even.');
        require(abs(in.root_le.y) < 1e-12, 'root_le.y must be 0.');
        require(abs(in.root_te.y) < 1e-12, 'root_te.y must be 0.');
        require(abs(in.tip_le.y - in.tip_te.y) < 1e-12, 'tip_le.y and tip_te.y must match.');
        require(in.tip_le.y > 0.0, 'tip_le.y must be > 0 (half-wing in +y).');

        c_root = in.root_te.x - in.root_le.x;
        c_tip  = in.tip_te.x  - in.tip_le.x;
        require(c_root > 1e-12, 'Root chord must be > 0 (root_te.x > root_le.x).');
        require(c_tip  > 1e-12, 'Tip chord must be > 0 (tip_te.x > tip_le.x).');

        % ---- Derived geometry ----
        hs = half_span(in);
        span = 2.0 * hs;
        S = wing_area_full(in);
        require(S > 0.0, 'Wing area S must be > 0.');

        Lambda = (span * span) / S;

        % ---- Build the linear system for A_n (half-wing) ----
        N = in.N_full / 2;

        M = zeros(N, N);
        b = zeros(N, 1); % RHS in M*A = b

        for i = 1:N
            Theta = i * pi / (N + 1);

            % y(Theta) = -(span/2) cos(Theta); use |y| for symmetric geometry
            y_abs = abs((-span * 0.5) * cos(Theta));

            c_i = chord_at_abs_y(in, y_abs);
            require(c_i > 1e-12, 'Chord must be > 0 everywhere.');

            alpha_local  = in.alpha + alpha_geo_at_abs_y(in, y_abs);
            alpha0_local = in.alpha_0;

            b(i) = alpha_local - alpha0_local;

            sinTheta = sin(Theta);
            require(abs(sinTheta) > 1e-12, 'sin(Theta_i) too small; check N.');

            for n = 1:N
                sin_nT = sin(n * Theta);
                term1 = (2.0 * span) / (pi * c_i);
                term2 = n / sinTheta;
                M(i, n) = sin_nT * (term1 + term2);
            end
        end

        % ---- Solve for Fourier coefficients ----
        A = solve_linear_system(M, b);

        % ---- Global coefficients ----
        cL = A(1) * pi * Lambda;

        s = 0.0;
        for n = 1:N
            s = s + n * A(n) * A(n);
        end
        cDi = pi * Lambda * s;

        cDi_ell = (cL * cL) / (pi * Lambda);

        e = 0.0;
        if cDi > 1e-16
            e = cDi_ell / cDi;
        end

        dcL_dalpha = 0.0;
        if in.a0 > 0.0 && Lambda > 1e-16 && e > 1e-16
            dcL_dalpha = in.a0 / (1.0 + in.a0 / (pi * Lambda * e));
        end

        % Pack result
        res.A = A(:);
        res.span = span;
        res.S = S;
        res.Lambda = Lambda;
        res.cL = cL;
        res.cDi = cDi;
        res.cDi_ell = cDi_ell;
        res.e = e;
        res.dcL_dalpha = dcL_dalpha;
    end

    function write_distributions_full_wing(in, res, filename)

        Uinf = in.Uinf;
        Nf = in.N_full;
        span = res.span;

        fid = fopen(filename, 'w');
        if fid < 0
            error('Cannot open output file.');
        end

        % Header (comment lines)
        fprintf(fid, '# LLT distributions over full wing (monotone y)\n');
        fprintf(fid, '# N_full=%d\n', Nf);

        fprintf(fid, '# Angles (rad): alpha=% .12e alpha_geo_root=% .12e alpha_geo_tip=% .12e alpha0=% .12e\n', ...
            in.alpha, in.alpha_geo_root, in.alpha_geo_tip, in.alpha_0);

        fprintf(fid, '# Angles (deg): alpha=% .12e alpha_geo_root=% .12e alpha_geo_tip=% .12e alpha0=% .12e\n', ...
            rad2deg(in.alpha), rad2deg(in.alpha_geo_root), rad2deg(in.alpha_geo_tip), rad2deg(in.alpha_0));

        fprintf(fid, '# Uinf=% .12e\n', Uinf);
        fprintf(fid, '# span=% .12e  S=% .12e  Lambda=% .12e\n', span, res.S, res.Lambda);

        fprintf(fid, '# cL=% .12e  cDi=% .12e  cDi_ell=% .12e  e=% .12e\n', res.cL, res.cDi, res.cDi_ell, res.e);
        fprintf(fid, '# dcL/dalpha=% .12e [1/rad]\n', res.dcL_dalpha);

        fprintf(fid, '# Columns:\n');
        fprintf(fid, '#  1:y 2:Theta 3:c 4:alpha 5:alpha0 6:alpha_i 7:alpha_eff 8:Gamma 9:cl 10:Gamma_ell 11:cl_ell\n');

        % Data rows in scientific format (similar to C++)
        for j = 1:Nf
            Theta = j * pi / (Nf + 1);

            y = -(span * 0.5) * cos(Theta);
            y_abs = abs(y);

            c = chord_at_abs_y(in, y_abs);

            alpha_local = in.alpha + alpha_geo_at_abs_y(in, y_abs);
            alpha0_local = in.alpha_0;

            alpha_i = alpha_i_of_theta(res.A, Theta);
            alpha_eff = alpha_local - alpha_i;

            Gamma = gamma_of_theta(span, Uinf, res.A, Theta);
            cl = (2.0 * Gamma) / (Uinf * c);

            GammaE = gamma_elliptic_of_theta(span, Uinf, res.A(1), Theta);
            clE = (2.0 * GammaE) / (Uinf * c);

            fprintf(fid, '% .10e % .10e % .10e % .10e % .10e % .10e % .10e % .10e % .10e % .10e % .10e\n', ...
                y, Theta, c, alpha_local, alpha0_local, alpha_i, alpha_eff, Gamma, cl, GammaE, clE);
        end

        fclose(fid);
    end

    % ---- Series evaluation helpers ----

    function Gamma = gamma_of_theta(span, Uinf, A, Theta)
        N = length(A);
        s = 0.0;
        for n = 1:N
            s = s + A(n) * sin(n * Theta);
        end
        Gamma = 2.0 * span * Uinf * s;
    end

    function GammaE = gamma_elliptic_of_theta(span, Uinf, A1, Theta)
        GammaE = 2.0 * span * Uinf * A1 * sin(Theta);
    end

    function alpha_i = alpha_i_of_theta(A, Theta)
        N = length(A);
        sinTheta = sin(Theta);
        if abs(sinTheta) < 1e-14
            alpha_i = 0.0;
            return;
        end
        s = 0.0;
        for n = 1:N
            s = s + n * A(n) * sin(n * Theta) / sinTheta;
        end
        alpha_i = s;
    end

    % ---- Geometry helpers ----

    function hs = half_span(in)
        hs = abs(in.tip_le.y);
    end

    function c = chord_at_abs_y(in, y_abs)
        hs = half_span(in);
        require(hs > 0.0, 'Half-span must be > 0.');
        require(y_abs >= -1e-12 && y_abs <= hs + 1e-12, '|y| must be within [0, b/2].');

        t = y_abs / hs;

        x_le = lerp(in.root_le.x, in.tip_le.x, t);
        x_te = lerp(in.root_te.x, in.tip_te.x, t);

        c = x_te - x_le;
    end

    function a = alpha_geo_at_abs_y(in, y_abs)
        hs = half_span(in);
        if hs > 0.0
            t = y_abs / hs;
        else
            t = 0.0;
        end
        a = lerp(in.alpha_geo_root, in.alpha_geo_tip, t);
    end

    function S = wing_area_full(in)
        hs = half_span(in);
        c_root = in.root_te.x - in.root_le.x;
        c_tip  = in.tip_te.x  - in.tip_le.x;
        S = 2.0 * hs * (c_root + c_tip) * 0.5;
    end

    % ---- Utility helpers ----

    function require(cond, msg)
        if ~cond
            error(['Input error: ', msg]);
        end
    end

    function y = lerp(a, b, t)
        y = a + (b - a) * t;
    end

    function d = rad2deg(x)
        d = x * 180.0 / pi;
    end

    % ---- Gauss-Jordan solver with partial pivoting ----

    function x = solve_linear_system(A, b)
        % Solves A x = b by Gauss-Jordan elimination with partial pivoting.
        % This follows the C++ implementation closely.
        n = length(b);

        for i = 1:n
            % Pivot row search
            pivot_row = i;
            for j = i+1:n
                if abs(A(j,i)) > abs(A(pivot_row,i))
                    pivot_row = j;
                end
            end

            % Swap rows
            if pivot_row ~= i
                tmp = A(i,:); A(i,:) = A(pivot_row,:); A(pivot_row,:) = tmp;
                tmpb = b(i);  b(i)  = b(pivot_row);  b(pivot_row)  = tmpb;
            end

            divisor = A(i,i);
            if abs(divisor) < 1e-12
                fprintf('Warning: Matrix is singular or ill-conditioned!\n');
            end

            % Normalize pivot row
            A(i,i:n) = A(i,i:n) / divisor;
            b(i) = b(i) / divisor;

            % Eliminate pivot column in all other rows
            for k = 1:n
                if k ~= i
                    factor = A(k,i);
                    A(k,i:n) = A(k,i:n) - factor * A(i,i:n);
                    b(k) = b(k) - factor * b(i);
                end
            end
        end

        x = b;
    end

end
