/*
 * Copyright (c) 2026 Olaf Frommann. All rights reserved.
 * This file is part of "Prandtl Lifting-Line Theory (LLT) - Deep Documentation of a Teaching C++ Implementation".
 * Distributed under the terms defined in 'LICENSE.txt', which is part of this source code package.
 *
 * Official source and verification: https://github.com/of33/LLT
 */

// Compile using gnu c++ compiler
// on linux: g++ -o LLT LLT.cpp -O
// on windows: g++ -o LLT.exe LLT.cpp -O
// adapt desired values for wing shape, number of collocation points N_full, u_inf and AoA in g_in
// start on linux using ./LLT
// start on windows using .\LLT.exe


#include <vector>
#include <cmath>
#include <iostream>
#include <cstdlib>   // std::exit
#include <fstream>
#include <iomanip>

// ============================================================================
// Lifting-Line Theory (LLT) with Glauert solution (Prandtl lifting line)
// ----------------------------------------------------------------------------
// This single-file implementation follows the lecture equations:
//
//  - Coordinate transform:  y = -(b/2) cos(Theta),  Theta in (0, pi)
//  - Fourier ansatz:        Gamma(Theta) = 2 b U_inf * sum_{n=1..N} A_n sin(n Theta)
//  - Glauert result:        alpha_i(Theta) = sum_{n=1..N} n A_n * sin(n Theta)/sin(Theta)
//  - Linear system for A_n: alpha(Theta) = 2b/(pi c(Theta)) * sum A_n sin(nTheta)
//                           + alpha_0(Theta) + sum n A_n sin(nTheta)/sinTheta
//
// The input is a HALF-wing planform described by 4 corner points (LE/TE at root and tip).
// We assume the wing is symmetric, so geometry functions use |y|.
//
// Output: distributions over the FULL wing, written as a gnuplot-friendly ASCII file.
// ============================================================================


// ------------------------------
// User input (global configuration)
// ------------------------------

struct Point2D {
    // x ... chordwise coordinate, y ... spanwise coordinate
    double x;
    double y;
};

struct LLTInput {
    // Planform corners for HALF wing:
    //  - root_le and root_te must have y == 0.0
    //  - tip_le and tip_te must have same y == b/2 (consistent half-span)
    //  - TE must be behind LE (x_te > x_le)
    Point2D root_le;
    Point2D root_te;
    Point2D tip_le;
    Point2D tip_te;

    // Aerodynamic / operating inputs
    double Uinf;             // free-stream velocity (only affects absolute Gamma; cl, cL are independent)
    double alpha;            // wing angle of attack [rad]
    double alpha_geo_root;   // geometric twist at root [rad]
    double alpha_geo_tip;    // geometric twist at tip  [rad]
    double alpha_0;          // 2D zero-lift angle [rad] (constant profile for all sections)
    double a0;               // 2D lift-curve slope dc_l/dalpha [1/rad], e.g. 2*pi

    // Numerical input
    // N_full = number of output stations on FULL wing; must be even.
    // Internally, we solve with N = N_full/2 Fourier coefficients (symmetric wing).
    int N_full;
};

// Example global instance (user edits this)
LLTInput g_in = {
    {0.0, 0.0},   // root LE
    {2.0, 0.0},   // root TE
    {0.5, 5.0},   // tip LE  (y = b/2)
    {1.5, 5.0},   // tip TE  (y = b/2)
    30.0,                // U_inf
    2.0 * M_PI/180.0,    // alpha
    0.0 * M_PI/180.0,    // alpha_geo_root
    0.0 * M_PI/180.0,    // alpha_geo_tip
    0.0 * M_PI/180.0,    // alpha_0
    2.0 * M_PI,          // a0 = dc_l/dalpha (thin-airfoil theory)
    40                   // N_full (even)
};


// ------------------------------
// Gauss-Jordan solver
// ------------------------------
// Solves A x = b by Gauss-Jordan elimination with partial pivoting.
// Note: This overwrites local copies of A and b (passed by value).

std::vector<double> solve_linear_system(std::vector<std::vector<double> > A,
                                        std::vector<double> b)
{
    int n = (int)A.size();

    // Loop over pivot columns
    for (int i = 0; i < n; i++) {

        // Find pivot row (largest absolute value in column i) for numerical stability
        int pivot_row = i;
        for (int j = i + 1; j < n; j++) {
            if (std::abs(A[j][i]) > std::abs(A[pivot_row][i])) {
                pivot_row = j;
            }
        }

        // Swap pivot row into position
        std::swap(A[i], A[pivot_row]);
        std::swap(b[i], b[pivot_row]);

        // Normalize pivot row
        double divisor = A[i][i];
        if (std::abs(divisor) < 1e-12) {
            std::cerr << "Warning: Matrix is singular or ill-conditioned!" << std::endl;
        }
        for (int j = i; j < n; j++) A[i][j] /= divisor;
        b[i] /= divisor;

        // Eliminate column i in all other rows
        for (int k = 0; k < n; k++) {
            if (k != i) {
                double factor = A[k][i];
                for (int j = i; j < n; j++) A[k][j] -= factor * A[i][j];
                b[k] -= factor * b[i];
            }
        }
    }

    // Now A should be the identity and b is the solution vector
    return b;
}


// ------------------------------
// LLT utilities (geometry, checks, helper math)
// ------------------------------

static double rad2deg(double x) { return x * 180.0 / M_PI; }

// Simple input validation helper. We abort early to avoid silent nonsense results.
static void require(bool cond, const char* msg)
{
    if (!cond) {
        std::cerr << "Input error: " << msg << std::endl;
        std::exit(1);
    }
}

// Linear interpolation: a -> b with parameter t in [0,1]
static double lerp(double a, double b, double t)
{
    return a + (b - a) * t;
}

// Compute half-span b/2 from tip y (assuming root y = 0).
// We keep abs() here, but later we also enforce tip y > 0 as a convention.
static double half_span(const LLTInput& in)
{
    return std::abs(in.tip_le.y);
}

// Compute chord c(|y|) from the given trapezoidal half-wing planform.
// We linearly interpolate LE and TE x-coordinates between root and tip.
static double chord_at_abs_y(const LLTInput& in, double y_abs)
{
    double hs = half_span(in);
    require(hs > 0.0, "Half-span must be > 0.");
    require(y_abs >= -1e-12 && y_abs <= hs + 1e-12, "|y| must be within [0, b/2].");

    // Non-dimensional spanwise coordinate for interpolation
    double t = y_abs / hs;

    // Interpolate leading and trailing edge positions
    double x_le = lerp(in.root_le.x, in.tip_le.x, t);
    double x_te = lerp(in.root_te.x, in.tip_te.x, t);

    // Local chord is TE minus LE
    return x_te - x_le;
}

// Linear geometric twist alpha_geo(|y|) from root to tip.
// This is added to the global angle of attack alpha.
static double alpha_geo_at_abs_y(const LLTInput& in, double y_abs)
{
    double hs = half_span(in);
    double t = (hs > 0.0) ? (y_abs / hs) : 0.0;
    return lerp(in.alpha_geo_root, in.alpha_geo_tip, t);
}

// Full wing area S from trapezoidal half-wing area (times 2).
static double wing_area_full(const LLTInput& in)
{
    double hs = half_span(in);

    double c_root = in.root_te.x - in.root_le.x;
    double c_tip  = in.tip_te.x  - in.tip_le.x;

    // Half-wing trapezoid area: A_half = hs * (c_root + c_tip) / 2
    // Full wing: S = 2 * A_half
    return 2.0 * hs * (c_root + c_tip) * 0.5;
}

static LLTInput with_alpha(const LLTInput& in, double alpha_new)
{
    LLTInput tmp = in;
    tmp.alpha = alpha_new;
    return tmp;
}

// ------------------------------
// LLT series evaluation (Gamma, alpha_i) from Fourier coefficients A_n
// ------------------------------

// Circulation distribution from Fourier series (lecture equation).
static double gamma_of_theta(double b, double Uinf,
                             const std::vector<double>& A, double Theta)
{
    int N = (int)A.size();
    double sum = 0.0;

    // Sum_{n=1..N} A_n sin(n Theta)
    for (int n = 1; n <= N; n++) {
        sum += A[n - 1] * std::sin((double)n * Theta);
    }

    // Gamma(Theta) = 2 b U_inf * sum(...)
    return 2.0 * b * Uinf * sum;
}

// Elliptic reference distribution with same total circulation.
// In Fourier terms this is simply keeping only A1.
static double gamma_elliptic_of_theta(double b, double Uinf,
                                      double A1, double Theta)
{
    return 2.0 * b * Uinf * A1 * std::sin(Theta);
}

// Induced angle of attack alpha_i(Theta) from Glauert result (lecture equation).
// alpha_i = sum_{n=1..N} n A_n * sin(nTheta)/sinTheta
static double alpha_i_of_theta(const std::vector<double>& A, double Theta)
{
    int N = (int)A.size();
    double sinTheta = std::sin(Theta);

    // Theta is never exactly 0 or pi for our collocation points, but guard anyway.
    if (std::abs(sinTheta) < 1e-14) return 0.0;

    double sum = 0.0;
    for (int n = 1; n <= N; n++) {
        sum += (double)n * A[n - 1] * std::sin((double)n * Theta) / sinTheta;
    }
    return sum;
}


// ------------------------------
// LLT solver
// ------------------------------

struct LLTResult {
    // A[0] corresponds to A1, A[1] to A2, ...
    std::vector<double> A;

    // Basic planform and results
    double span;     // span
    double S;        // wing area
    double Lambda;   // aspect ratio b^2/S

    // Global coefficients from lecture formulas
    double cL;
    double cDi;
    double cDi_ell;    // induced drag for elliptic distribution with same cL
    double e;          // Oswald efficiency factor
    double dcL_dalpha; // finite-wing lift-curve slope [1/rad]
};

static LLTResult run_llt(const LLTInput& in)
{
    // --------------------------
    // 1) Input checks / conventions
    // --------------------------
    require(in.N_full >= 4, "N_full must be >= 4.");
    require((in.N_full % 2) == 0, "N_full must be even.");
    require(std::abs(in.root_le.y) < 1e-12, "root_le.y must be 0.");
    require(std::abs(in.root_te.y) < 1e-12, "root_te.y must be 0.");
    require(std::abs(in.tip_le.y - in.tip_te.y) < 1e-12, "tip_le.y and tip_te.y must match.");
    require(in.tip_le.y > 0.0, "tip_le.y must be > 0 (half-wing in +y).");

    // Chords must be positive (TE behind LE)
    double c_root = in.root_te.x - in.root_le.x;
    double c_tip  = in.tip_te.x  - in.tip_le.x;
    require(c_root > 1e-12, "Root chord must be > 0 (root_te.x > root_le.x).");
    require(c_tip  > 1e-12, "Tip chord must be > 0 (tip_te.x > tip_le.x).");

    // --------------------------
    // 2) Derived geometry
    // --------------------------
    double hs = half_span(in);
    double span  = 2.0 * hs;
    double S  = wing_area_full(in);
    require(S > 0.0, "Wing area S must be > 0.");

    // Aspect ratio Lambda = b^2 / S
    double Lambda = (span * span) / S;

    // --------------------------
    // 3) Build the linear system for A_n (half-wing)
    // --------------------------
    // We solve only for one half-wing because the planform is symmetric.
    // The lecture collocation uses Theta_i = i*pi/(N+1), i=1..N.
    //
    // We define N as number of Fourier terms (and equations) on the half-wing:
    // N = N_full/2
    int N = in.N_full / 2;

    // Matrix M and right-hand side b for M * A = b
    std::vector<std::vector<double> > M(N, std::vector<double>(N, 0.0));
    std::vector<double> b(N, 0.0);   // RHS vector in M*A = b

    // Fill rows i=1..N (stored at index i-1)
    for (int i = 1; i <= N; i++) {
        double Theta = (double)i * M_PI / (double)(N + 1);

        // Coordinate transform from the lecture: y(Theta) = -(b/2) cos(Theta)
        // For symmetric input geometry we only need |y|.
        double y_abs = std::abs((-span * 0.5) * std::cos(Theta));

        // Local chord length and local geometric angle
        double c_i = chord_at_abs_y(in, y_abs);
        require(c_i > 1e-12, "Chord must be > 0 everywhere.");

        double alpha_local  = in.alpha + alpha_geo_at_abs_y(in, y_abs);
        double alpha0_local = in.alpha_0; // constant profile in this simplified version

        // Move alpha0 to the right-hand side
        b[i - 1] = alpha_local - alpha0_local;

        // The Glauert term uses 1/sin(Theta), so Theta must not be too close to 0 or pi.
        double sinTheta = std::sin(Theta);
        require(std::abs(sinTheta) > 1e-12, "sin(Theta_i) too small; check N.");

        // Matrix entries:
        // M_{i n} = sin(n Theta_i) * ( 2b/(pi c_i) + n/sin(Theta_i) )
        for (int n = 1; n <= N; n++) {
            double sin_nT = std::sin((double)n * Theta);
            double term1  = (2.0 * span) / (M_PI * c_i);
            double term2  = ((double)n) / sinTheta;
            M[i - 1][n - 1] = sin_nT * (term1 + term2);
        }
    }

    // --------------------------
    // 4) Solve for Fourier coefficients A_n
    // --------------------------
    std::vector<double> A = solve_linear_system(M, b);

    // --------------------------
    // 5) Global coefficients from lecture formulas
    // --------------------------
    // cL = pi * Lambda * A1
    double cL = A[0] * M_PI * Lambda;

    // cDi = pi * Lambda * sum_{n=1..N} n * A_n^2
    double sum = 0.0;
    for (int n = 1; n <= N; n++) {
        sum += (double)n * A[n - 1] * A[n - 1];
    }
    double cDi = M_PI * Lambda * sum;

    // Elliptic induced drag for same cL:
    // cDi_ell = cL^2/(pi Lambda) = pi Lambda A1^2
    double cDi_ell = (cL * cL) / (M_PI * Lambda);

    // Oswald efficiency factor:
    // cDi = cL^2/(pi Lambda e)  =>  e = cDi_ell / cDi
    double e = 0.0;
    if (cDi > 1e-16) e = cDi_ell / cDi;

    // Pack result
    LLTResult out;
    out.A = A;
    out.span = span;
    out.S = S;
    out.Lambda = Lambda;
    out.cL = cL;
    out.cDi = cDi;
    out.cDi_ell = cDi_ell;
    out.e = e;

    // Lift-curve slope (including Oswald factor), see Eq. (dcL/dalpha general) in the documentation:
    // dcL/dalpha = a0 / (1 + a0/(pi*Lambda*e))
    double dcL_dalpha = 0.0;
    if (in.a0 > 0.0 && Lambda > 1e-16 && e > 1e-16) {
        dcL_dalpha = in.a0 / (1.0 + in.a0 / (M_PI * Lambda * e));
    }
    out.dcL_dalpha = dcL_dalpha;

    return out;
}


// ------------------------------
// Output: distributions over the full wing
// ------------------------------
// We write values at N_full stations, with
//   Theta_j = j*pi/(N_full+1), j=1..N_full,
// which gives a monotone y from approximately -b/2 to +b/2:
//   y = -(b/2) cos(Theta).
//
// Columns include an elliptic reference distribution (same A1 / same total circulation).

static void write_distributions_full_wing(const LLTInput& in,
                                          const LLTResult& res,
                                          const char* filename)
{
    double Uinf = in.Uinf;
    int Nf = in.N_full;
    double span = res.span;

    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Cannot open output file.\n";
        return;
    }

    // Header is comment-only (gnuplot ignores lines starting with '#')
    out << "# LLT distributions over full wing (monotone y)\n";
    out << "# N_full=" << Nf << "\n";

    out << "# Angles (rad):"
        << " alpha=" << in.alpha
        << " alpha_geo_root=" << in.alpha_geo_root
        << " alpha_geo_tip=" << in.alpha_geo_tip
        << " alpha0=" << in.alpha_0 << "\n";

    out << "# Angles (deg):"
        << " alpha=" << rad2deg(in.alpha)
        << " alpha_geo_root=" << rad2deg(in.alpha_geo_root)
        << " alpha_geo_tip=" << rad2deg(in.alpha_geo_tip)
        << " alpha0=" << rad2deg(in.alpha_0) << "\n";

    out << "# Uinf=" << Uinf << "\n";
    out << "# span=" << std::setprecision(12) << std::fixed << span
        << "  S=" << res.S << "  Lambda=" << res.Lambda << "\n";

    out << "# cL=" << res.cL
        << "  cDi=" << res.cDi
        << "  cDi_ell=" << res.cDi_ell
        << "  e=" << res.e << "\n"
        << "  dcL/dalpha=" << res.dcL_dalpha
        << " [1/rad]\n";

    out << "# Columns:\n";
    out << "#  1:y 2:Theta 3:c 4:alpha 5:alpha0 6:alpha_i 7:alpha_eff"
           " 8:Gamma 9:cl 10:Gamma_ell 11:cl_ell\n";

    // Scientific format keeps columns readable across different scales
    out << std::scientific << std::setprecision(10);

    for (int j = 1; j <= Nf; j++) {
        double Theta = (double)j * M_PI / (double)(Nf + 1);

        // Spanwise coordinate on the full wing
        double y = -(span * 0.5) * std::cos(Theta);

        // Geometry and twist are defined on the half-wing; use |y| for symmetry.
        double y_abs = std::abs(y);

        double c = chord_at_abs_y(in, y_abs);
        double alpha_local = in.alpha + alpha_geo_at_abs_y(in, y_abs);
        double alpha0_local = in.alpha_0;

        // Induced angle and effective angle
        double alpha_i = alpha_i_of_theta(res.A, Theta);
        double alpha_eff = alpha_local - alpha_i;

        // Circulation and sectional lift coefficient
        double Gamma = gamma_of_theta(span, Uinf, res.A, Theta);
        double cl = (2.0 * Gamma) / (Uinf * c);

        // Elliptic reference with same A1 (same total circulation / same cL)
        double GammaE = gamma_elliptic_of_theta(span, Uinf, res.A[0], Theta);
        double clE = (2.0 * GammaE) / (Uinf * c);

        out << y << " " << Theta << " " << c << " "
            << alpha_local << " " << alpha0_local << " "
            << alpha_i << " " << alpha_eff << " "
            << Gamma << " " << cl << " "
            << GammaE << " " << clE << "\n";
    }
}


// ------------------------------
// Main program
// ------------------------------

int main()
{
    // Solve LLT system and compute global coefficients
    LLTResult res = run_llt(g_in);

    // Write distributions for plotting and post-processing
    write_distributions_full_wing(g_in, res, "llt_distribution.dat");

    // Print a short summary to stdout
    std::cout << "span    = " << res.span << "\n";
    std::cout << "S       = " << res.S << "\n";
    std::cout << "Lambda  = " << res.Lambda << "\n";
    std::cout << "cL      = " << res.cL << "\n";
    std::cout << "cDi     = " << res.cDi << "\n";
    std::cout << "cDi_ell = " << res.cDi_ell << "\n";
    std::cout << "e       = " << res.e << "\n\n";

    // lift slope comparison
    double alpha1 = 0.0 * M_PI / 180.0;
    double alpha2 = 8.0 * M_PI / 180.0;

    LLTResult r1 = run_llt(with_alpha(g_in, alpha1));
    LLTResult r2 = run_llt(with_alpha(g_in, alpha2));

    double dcL_dalpha_num = (r2.cL - r1.cL) / (alpha2 - alpha1);

    std::cout << "\nLift-curve slope comparison:\n";
    std::cout << "dcL/dalpha (theory) = " << res.dcL_dalpha << " [1/rad]\n";
    std::cout << "dcL/dalpha (secant, 0..8 deg) = " << dcL_dalpha_num << " [1/rad]\n";
    std::cout << "difference = " << (dcL_dalpha_num - res.dcL_dalpha) << " [1/rad]\n\n";

    // Print Fourier coefficients A_n (useful for debugging and teaching)
    std::cout << "Fourier coefficients A_n:\n";
    for (int n = 1; n <= (int)res.A.size(); n++) {
        std::cout << "A_" << n << " = " << res.A[n - 1] << "\n";
    }

    return 0;
}
